﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HoleController : MonoBehaviour {

    private GroundController groundController;
    private EnemyController enemyController;

    private bool steppedOn = false;

    // Use this for initialization
    void Start () {

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();

        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");
   
    }

    void OnTriggerEnter(Collider other)
    {
        if (!(steppedOn))
        { 
            if (other.gameObject.tag == "Enemy")
            {
                enemyController.agent.Warp(new Vector3(1.0F, -1.9F, -1.0F));
                enemyController.falling = true;
                StartCoroutine(WaitForStep());
            }
        }
    }

    IEnumerator WaitForStep()
    {
        yield return new WaitForSeconds(0.1F);
        steppedOn = true;
        gameObject.transform.localScale += new Vector3(0, 0.4F, 0);

        groundController.surface.BuildNavMesh();
        enemyController.EnemyGo();
        StartCoroutine(WaitForFalling());
    }

    IEnumerator WaitForFalling()
    {
        yield return new WaitForSeconds(0.5F);
        enemyController.falling = false;
    }


}
