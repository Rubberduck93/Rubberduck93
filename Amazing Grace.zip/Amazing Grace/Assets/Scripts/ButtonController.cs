﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour {

    private GroundController groundController;
    private EnemyController enemyController;

    // Use this for initialization
    void Start () {

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();

        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");
    }

    public void BuildAndGo()
    {
        if (!(groundController.gameOn))
        {
            groundController.surface.BuildNavMesh();
            enemyController.EnemyGo();
        }    
    }

    public void LevelChoice(int Level)
    {
        groundController.gameLevel += Level;
        groundController.ResetLevel();
    }

    public void BackToPanel()
    {
        SceneManager.LoadScene(1);
    }

}
