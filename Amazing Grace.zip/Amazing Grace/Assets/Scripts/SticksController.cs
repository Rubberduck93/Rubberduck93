﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SticksController : MonoBehaviour {

    private GroundController groundController;
    private EnemyController enemyController;

    // Use this for initialization
    void Start()
    {

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();

        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");

    }

    void OnTriggerEnter(Collider other)
    {

        if (other.gameObject.tag == "Enemy")
        {
            enemyController.agent.isStopped = true;
            StartCoroutine(WaitForStop());

        }
    }

    IEnumerator WaitForStop()
    {
        yield return new WaitForSeconds(2F);
        enemyController.agent.isStopped = false;
    }
}
