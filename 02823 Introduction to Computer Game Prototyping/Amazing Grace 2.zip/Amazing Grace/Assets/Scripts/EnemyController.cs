﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;

public class EnemyController : MonoBehaviour {

    //public Camera cam;

    public NavMeshAgent agent;

    public Transform startPosition;
    public Transform endPosition;
   
    private GroundController groundController;

    private bool gameOver = false;
    public bool falling = false;

    public void Start()
    {
        agent = GetComponent<NavMeshAgent>();

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();

        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        //gameObject.transform.position = startPosition.position;
        //print("Start: " + startPosition.position);
    }

    public void EnemyGo()
    {
        NavMeshPath path = new NavMeshPath();
        bool hasFoundPath = agent.CalculatePath(endPosition.position, path);

        //Ray ray = new Ray(endPosition.position += new Vector3(0, 1, 0), new Vector3(0,-1,0));
        //Ray ray = new Ray(new Vector3(-6, -0.4F, 0), new Vector3(0, -1, 0));

        Ray ray = new Ray(new Vector3(endPosition.position.x, endPosition.position.y + 1, endPosition.position.z), new Vector3(0, -1, 0));
        RaycastHit hit;

        if (path.status == NavMeshPathStatus.PathComplete)
        {

            if (Physics.Raycast(ray, out hit))
            {
                // Move our agent
                agent.SetDestination(hit.point);
            }

            groundController.gameOn = true;
        }
        else
        {
            groundController.errorText.text = "There is no Path!";
            StartCoroutine(Wait());
        }
        
    }

    IEnumerator Wait()
    {
        yield return new WaitForSeconds(3.0F);
        groundController.errorText.text = "";      
    }

    void Update()
    {
        if (!gameOver && !falling && groundController.gameOn && !agent.pathPending)
            {
            if (agent.remainingDistance <= agent.stoppingDistance)
            {
                if (!agent.hasPath || agent.velocity.sqrMagnitude == 0f)
                {                  
                    groundController.GameResult();
                    gameOver = true;
                    
                }
            }
        }
    }

        /*
            // Ice - for uncontrollable speed
            if (Input.GetKeyDown("space"))
            {
                print("speed up");
                agent.speed = 10;
            }
            */

    public IEnumerator WaitAndEnemy()
    {
        yield return new WaitForSeconds(2F);
        agent.Warp(startPosition.position);
        agent.ResetPath();
        gameOver = false;

    }
}
