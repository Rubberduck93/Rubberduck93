﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrassController : MonoBehaviour {

    public GameObject Box;
    public GameObject Sticks;

    public Material Grass;
    public Material MouseOver;
    public Material SteppedOn;

    bool ready = false;
    bool steppedOn = false;

    private GameObject boxObject = null;

    private GroundController groundController;
    private EnemyController enemyController;

    private Vector3 startPos;

    // Use this for initialization
    void Start () {

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();
    
        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");

        startPos = gameObject.transform.position;

    }

    // Update is called once per frame
    void Update () {
    
        if (gameObject.transform.position.y > startPos.y - 0.8F)
        {
            gameObject.transform.position -= new Vector3(0, 0.01F, 0);
        }

        if (!ready)
        {
            if (boxObject == null)
            {
                StartCoroutine(Wait());
            }
        }   
    }

    void OnTriggerEnter(Collider other)
    {
        if (groundController.gameOn)
        {
            if (!steppedOn)
            {
                if (other.gameObject.tag == "Enemy")
                {
                    groundController.IncrementStepsCount();
                    steppedOn = true;
                    GetComponent<Renderer>().material = SteppedOn;
                }
            }
        }    
    }

    IEnumerator Wait()
    {
        yield return new WaitForSeconds(1.0F);
        ready = true;
    }

    void OnMouseOver()
    {
        if (ready && !groundController.gameOn)
        {
            // Create Box

            if (Input.GetMouseButton(0) && groundController.boxCount > 0)
            {
                groundController.BoxCount(-1);
                boxObject = Instantiate(Box, new Vector3(gameObject.transform.position.x, gameObject.transform.position.y + 0.35F, gameObject.transform.position.z), Quaternion.identity); //-0.65F
                ready = false;
            }

            // Create Sticks

            if (Input.GetMouseButton(1))
            {
                //groundController.BoxCount(-1);
                Instantiate(Sticks, new Vector3(gameObject.transform.position.x, gameObject.transform.position.y-0.05F, gameObject.transform.position.z), Quaternion.identity); //-0.65F
                ready = false;
                Destroy(gameObject);
            }

            //GetComponent<Renderer>().material.color = Color.yellow;
            GetComponent<Renderer>().material = MouseOver;
        }
        //print(gameObject.transform.position);
    }

    void OnMouseExit()
    {
        if (!groundController.gameOn)
        {
            GetComponent<Renderer>().material = Grass;
        }     
    }
}
