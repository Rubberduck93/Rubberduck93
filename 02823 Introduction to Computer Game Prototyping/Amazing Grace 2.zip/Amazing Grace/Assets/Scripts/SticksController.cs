﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SticksController : MonoBehaviour {

    public GameObject Grass;

    public Material Sticks;
    public Material MouseOver;

    private GroundController groundController;
    private EnemyController enemyController;

    bool ready = false;

    // Use this for initialization
    void Start()
    {

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();

        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");

        StartCoroutine(Wait());

    }

    IEnumerator Wait()
    {
        yield return new WaitForSeconds(0.5F);
        ready = true;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            enemyController.agent.isStopped = true;
            StartCoroutine(WaitForStop());

        }
    }

    IEnumerator WaitForStop()
    {
        yield return new WaitForSeconds(2F);
        enemyController.agent.isStopped = false;
    }

    void OnMouseOver()
    {

        if (ready && !groundController.gameOn)
        {
            // Destroy Box

            if (Input.GetMouseButton(1))
            {
                //groundController.BoxCount(1);
                Instantiate(Grass, new Vector3(gameObject.transform.position.x, gameObject.transform.position.y+0.85F, gameObject.transform.position.z), Quaternion.identity); //-0.65F
                Destroy(gameObject);
            }

            GetComponent<Renderer>().material = MouseOver;
        }
    }

    void OnMouseExit()
    {
        if (!groundController.gameOn)
        {
            GetComponent<Renderer>().material = Sticks;
        }
        //ready = true;
    }
}
