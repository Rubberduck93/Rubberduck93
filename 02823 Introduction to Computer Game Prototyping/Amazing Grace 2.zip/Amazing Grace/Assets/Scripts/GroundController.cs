﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class GroundController : MonoBehaviour
{
    public GameObject LesserGround;
    public GameObject Grass;
    public GameObject Hole;

    public Transform startPosition;
    public Transform endPosition;

    public Light lighting;

    public bool gameOn;

    public Text levelText;
    public int gameLevel;

    public Text boxText;
    public int boxCount;

    public Text stepsText;
    public int stepsCount;

    public Text errorText;
    public Text winText;

    public Text bronzeText;
    public Text silverText;
    public Text goldText;

    private int bronzeNumber;
    private int silverNumber;
    private int goldNumber;

    public Image winBronzeImage;
    public Image winSilverImage;
    public Image winGoldImage;

    public Button restartButton;
    public Button nextButton;
    public Button previousButton;

    public NavMeshSurface surface;

    private int GroundSize = 5;

    GameObject[] destroyLesserGround;
    GameObject[] destroyGrass;
    GameObject[] destroyBox;

    private EnemyController enemyController;
    private MainController mainController;

    // Use this for initialization
    void Start()
    {
        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        GameObject mainControllerObject = GameObject.FindWithTag("MainCamera");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");

        if (mainControllerObject != null) mainController = mainControllerObject.GetComponent<MainController>();

        if (mainController == null) Debug.Log("Cannot find 'MainController' script");

        gameLevel = mainController.CurrentLevel;

        LevelPreperations(); 
        StartCoroutine(BuildGroundGrass());
    }

    // Reset Level

    public void ResetLevel()
    {
        LevelPreperations();
        StartCoroutine(WaitAndBuild());  
    }

    IEnumerator WaitAndBuild()
    {
        yield return new WaitForSeconds(0.1F);
        StartCoroutine(BuildGroundGrass());
    }

    public void LevelPreperations()
    {
        // Resetting Values
        lighting.color = new Color(1.0F, 0.957F, 0.839F, 1.0F);
        stepsCount = 0;
        gameOn = false;
        winText.text = "";
        winBronzeImage.gameObject.SetActive(false);
        winSilverImage.gameObject.SetActive(false);
        winGoldImage.gameObject.SetActive(false);

        restartButton.gameObject.SetActive(false);
        nextButton.gameObject.SetActive(false);
        previousButton.gameObject.SetActive(false);

        // Setting up the Level
        if (gameLevel == 1)
        {
            GroundSize7x7();

            bronzeNumber = 10;
            silverNumber = 15;
            goldNumber = 20;

            boxCount = 12;
        }
        if (gameLevel == 2)
        {
            GroundSize9x9();

            bronzeNumber = 25;
            silverNumber = 33;
            goldNumber = 41;

            boxCount = 8;
        }
        if (gameLevel == 3)
        {
            GroundSize9x9();

            bronzeNumber = 41;
            silverNumber = 45;
            goldNumber = 49;

            boxCount = 20;
        }
        if (gameLevel == 4)
        {
            GroundSize9x9();

            bronzeNumber = 41;
            silverNumber = 45;
            goldNumber = 49;

            boxCount = 20;
        }
        if (gameLevel == 5)
        {
            GroundSize11x11();

            bronzeNumber = 41;
            silverNumber = 45;
            goldNumber = 49;

            boxCount = 20;
        }
        if (gameLevel == 6)
        {
            GroundSize5x5();

            bronzeNumber = 41;
            silverNumber = 45;
            goldNumber = 49;

            boxCount = 20;
        }


        // Updating Text
        levelText.text = "Level: " + gameLevel.ToString();
        boxText.text = "x " + boxCount.ToString();
        stepsText.text = stepsCount.ToString();

        bronzeText.text = bronzeNumber.ToString();
        silverText.text = silverNumber.ToString();
        goldText.text = goldNumber.ToString();

        // Destroy All Objects except for Enemy
        DestroyAllObjects();

    }

    public IEnumerator BuildGroundGrass()
    {
        
        for (int x = GroundSize; x >= -GroundSize; x--)
        {
            for (int z = GroundSize; z >= -GroundSize; z--)
            {
                
                if (gameLevel == 1)
                {
                    InstantiateGroundGrass(x, z);
                }
                if (gameLevel == 2)
                {
                    if (!((Mathf.Abs(x) == 1 || Mathf.Abs(x) == 2 || Mathf.Abs(x) == 3) && (Mathf.Abs(z) == 1 || Mathf.Abs(z) == 3)))
                    {
                        InstantiateGroundGrass(x, z);
                    }                  
                }
                if (gameLevel == 3)
                {
                    
                    if (!((Mathf.Abs(x) == 1 || Mathf.Abs(x) == 3) && (Mathf.Abs(z) == 1 || Mathf.Abs(z) == 3)))
                    {
                        InstantiateGroundGrass(x,z);                      
                    }
                 
                }
                if (gameLevel == 4)
                {
                    if (!((Mathf.Abs(x) == 0 || Mathf.Abs(x) == 2 || Mathf.Abs(x) == 3) && (Mathf.Abs(z) == 3)))
                    {
                        InstantiateGroundGrass(x, z);
                    }
                }
                if (gameLevel == 5)
                {
                    InstantiateGroundGrass(x, z);
                }
                if (gameLevel == 6)
                {
                    if ((x == 1.0 && z ==-1.0))
                    {
                        // Hole up
                        Instantiate(Hole, new Vector3(x, 1.5F, z), Quaternion.identity);
                        // Ground + Grass down
                        Instantiate(Grass, new Vector3(x, -1.6F, z), Quaternion.identity);
                        Instantiate(LesserGround, new Vector3(x, -3.8F, z), Quaternion.identity);                      
                    }
                    else
                    {
                        NewInstantiateGroundGrass(x, z);
                    }                      
                }
                yield return new WaitForSeconds(0.02F);
            }
        }

        BuildStairs();
        //surface.BuildNavMesh();
        StartCoroutine(WaitAndSurface());
        StartCoroutine(enemyController.WaitAndEnemy());
    }

    IEnumerator WaitAndSurface()
    {
        yield return new WaitForSeconds(1.5F);
        surface.BuildNavMesh();
    }

    void InstantiateGroundGrass(int x, int z)
    {
        Instantiate(Grass, new Vector3(x, 0.6F, z), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(x, -1.6F, z), Quaternion.identity);       
    }

    void NewInstantiateGroundGrass(int x, int z)
    {
        // Up
        Instantiate(Grass, new Vector3(x, 2.3F, z), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(x, 0.1F, z), Quaternion.identity);

        // Down
        Instantiate(Grass, new Vector3(x, -1.6F, z), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(x, -3.8F, z), Quaternion.identity);        
    }

    void BuildStairs()
    {
        // End
        /*
        Instantiate(Grass, new Vector3(3, 2.9F, 3), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(3, 0.7F, 3), Quaternion.identity);

        Instantiate(Grass, new Vector3(3, 2.9F, 2), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(3, 0.7F, 2), Quaternion.identity);
        */
        //Instantiate(Grass, new Vector3(2, 1.9F, 3), Quaternion.identity);
        //Instantiate(LesserGround, new Vector3(2, -0.3F, 3), Quaternion.identity);

        //Instantiate(Grass, new Vector3(2, 2.9F, 2), Quaternion.identity);
        //Instantiate(LesserGround, new Vector3(2, 0.7F, 2), Quaternion.identity);

        Grass.transform.localScale -= new Vector3(0.5F, 0, 0);
        LesserGround.transform.localScale -= new Vector3(0.5F, 0, 0);

        float upY = 0;

        // Middle
        for (float x = -2.25F; x < 2.5; x+=0.5F)
        {
            upY += 0.4F;
            //LesserGround.transform.localScale += new Vector3(0, 0.05F, 0);

            Instantiate(Grass, new Vector3(x, -2.0F+upY, 3), Quaternion.identity);
            Instantiate(LesserGround, new Vector3(x, -4.2F+upY, 3), Quaternion.identity);
        }

        Grass.transform.localScale += new Vector3(0.5F, 0, 0);
        LesserGround.transform.localScale = new Vector3(1, 1, 1);

        // Start
        //Instantiate(Grass, new Vector3(-2, -1.6F, 3), Quaternion.identity);
        //Instantiate(LesserGround, new Vector3(-2, -3.8F, 3), Quaternion.identity);
    }

    public void GameResult()
    {
        lighting.color = Color.black;

        if (stepsCount < bronzeNumber)
        {
            winText.text = "Try Again";
        }
        // Bronze
        if (stepsCount >= bronzeNumber && stepsCount < silverNumber)
        {
            winText.text = "BRONZE!";
            winBronzeImage.gameObject.SetActive(true);
            mainController.Medals[gameLevel - 1] = "Bronze";
        }
        // Silver
        if (stepsCount >= silverNumber && stepsCount < goldNumber)
        {
            winText.text = "SILVER!";
            winSilverImage.gameObject.SetActive(true);
            mainController.Medals[gameLevel - 1] = "Silver";
        }
        // Gold
        if (stepsCount >= goldNumber)
        {
            winText.text = "GOLD!";
            winGoldImage.gameObject.SetActive(true);
            mainController.Medals[gameLevel - 1] = "Gold";
        }

        restartButton.gameObject.SetActive(true);

        if (gameLevel != 1) previousButton.gameObject.SetActive(true);
        if (stepsCount >= bronzeNumber) nextButton.gameObject.SetActive(true);

    }

    public void BoxCount(int value)
    {
        boxCount += value;
        boxText.text = "x " + boxCount.ToString();
    }

    public void IncrementStepsCount()
    {
        stepsCount++;
        stepsText.text = stepsCount.ToString();
    }

    void GroundSize5x5()
    {
        GroundSize = 2;
        endPosition.transform.position = new Vector3(0, 1.8F, 0);
        startPosition.transform.position = new Vector3(-2.0F, -2.2F, -2.0F);
    }

    void GroundSize7x7()
    {
        GroundSize = 3;
        endPosition.transform.position = new Vector3(-4, -0.8F, 0);
        startPosition.transform.position = new Vector3(4, -0.8F, 0);
    }

    void GroundSize9x9()
    {
        GroundSize = 4;
        endPosition.transform.position = new Vector3(-5, -0.8F, 0);
        startPosition.transform.position = new Vector3(5, -0.8F, 0);
    }

    void GroundSize11x11()
    {
        GroundSize = 5;
        endPosition.transform.position = new Vector3(-6, -0.8F, 0);
        startPosition.transform.position = new Vector3(6, -0.8F, 0);
    }

    void GroundSize13x13()
    {
        GroundSize = 6;
        endPosition.transform.position = new Vector3(-7, -0.8F, 0);
        startPosition.transform.position = new Vector3(7, -0.8F, 0);
    }

    void DestroyAllObjects()
    {
        destroyLesserGround = GameObject.FindGameObjectsWithTag("LesserGround");

        for (var i = 0; i < destroyLesserGround.Length; i++)
        {
            Destroy(destroyLesserGround[i]);
        }

        destroyGrass = GameObject.FindGameObjectsWithTag("Grass");

        for (var i = 0; i < destroyGrass.Length; i++)
        {
            Destroy(destroyGrass[i]);
        }

        destroyBox = GameObject.FindGameObjectsWithTag("Box");

        for (var i = 0; i < destroyBox.Length; i++)
        {
            Destroy(destroyBox[i]);
        }

    }


}
