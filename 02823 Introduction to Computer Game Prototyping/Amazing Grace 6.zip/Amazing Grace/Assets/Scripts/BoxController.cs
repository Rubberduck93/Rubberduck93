﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxController : MonoBehaviour {

    public Material Box;
    public Material MouseOver;

    bool ready = false;

    private GroundController groundController;
    private EnemyController enemyController;

    // Use this for initialization
    void Start () {

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();

        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");

        StartCoroutine(Wait());
    }

    IEnumerator Wait()
    {
        yield return new WaitForSeconds(0.5F);
        ready = true;
    }

    void OnMouseOver()
    {
        if (ready && !groundController.gameOn)
        {
            // Destroy Box

            if (Input.GetMouseButton(0))
            {
                groundController.BoxCount(1);
                Destroy(gameObject);
            }

            GetComponent<Renderer>().material = MouseOver;
        }   
    }

    void OnMouseExit()
    {
        if (!groundController.gameOn)
        {
            GetComponent<Renderer>().material = Box;
        }      
        //ready = true;
    }
}
