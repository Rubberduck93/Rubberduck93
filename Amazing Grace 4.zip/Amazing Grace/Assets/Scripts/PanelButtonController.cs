﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class PanelButtonController : MonoBehaviour {

    private MainController mainController;

    public Image[] Medals;

    // Use this for initialization
    void Start()
    {
        GameObject mainControllerObject = GameObject.FindWithTag("MainCamera");

        if (mainControllerObject != null) mainController = mainControllerObject.GetComponent<MainController>();

        if (mainController == null) Debug.Log("Cannot find 'MainController' script");


        for (var i = 0; i < mainController.Medals.Length; i++)
        {
            if (mainController.Medals[i] == "Bronze")
            {
                Medals[i].gameObject.SetActive(true);
                Medals[i].gameObject.GetComponent<Image>().color = new Color32(219, 112, 61, 255);
            }
            if (mainController.Medals[i] == "Silver")
            {
                Medals[i].gameObject.SetActive(true);
                Medals[i].gameObject.GetComponent<Image>().color = Color.grey;
            }
            if (mainController.Medals[i] == "Gold")
            {
                Medals[i].gameObject.SetActive(true);
                Medals[i].gameObject.GetComponent<Image>().color = Color.yellow;
            }
        }  
         
        
    }

    public void Home()
    {
        SceneManager.LoadScene(0);
    }

    public void Panel()
    {
        SceneManager.LoadScene(1);
    }

    public void PanelGoToLevel(int Level)
    {
        mainController.CurrentLevel = Level;
        SceneManager.LoadScene(2);
    }
}
