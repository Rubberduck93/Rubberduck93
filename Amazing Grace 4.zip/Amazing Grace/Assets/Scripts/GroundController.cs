﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class GroundController : MonoBehaviour
{
    public GameObject LesserGround;
    public GameObject Grass;
    public GameObject Warp;

    public Transform startPosition;
    public Transform endPosition;

    public Light lighting;

    public bool gameOn;

    public RectTransform BoxToggle;
    public RectTransform BoxBackground;

    public RectTransform TarToggle;
    public RectTransform TarBackground;

    public Text levelText;
    public int gameLevel;

    public Text stepsText;
    private float theTime;
    private string stepSeconds;
    private float floatStepSeconds;

    public Text boxText;
    public int boxCount;

    public Text tarText;
    public int tarCount;

    public Text errorText;
    public Text winText;

    public Text bronzeText;
    public Text silverText;
    public Text goldText;

    private int bronzeNumber;
    private int silverNumber;
    private int goldNumber;

    public Image winBronzeImage;
    public Image winSilverImage;
    public Image winGoldImage;

    public Button restartButton;
    public Button nextButton;
    public Button previousButton;

    public NavMeshSurface surface;

    private int GroundSize = 5;

    GameObject[] destroyLesserGround;
    GameObject[] destroyGrass;
    GameObject[] destroyBox;
    GameObject[] destroyWarp;

    private EnemyController enemyController;
    private MainController mainController;

    

    // Use this for initialization
    void Start()
    {
        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        GameObject mainControllerObject = GameObject.FindWithTag("MainCamera");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");

        if (mainControllerObject != null) mainController = mainControllerObject.GetComponent<MainController>();

        if (mainController == null) Debug.Log("Cannot find 'MainController' script");

        gameLevel = mainController.CurrentLevel;

        LevelPreperations(); 
        StartCoroutine(BuildGroundGrass());
    }

    // Reset Level

    public void ResetLevel()
    {
        LevelPreperations();
        StartCoroutine(WaitAndBuild());  
    }

    IEnumerator WaitAndBuild()
    {
        yield return new WaitForSeconds(0.1F);
        StartCoroutine(BuildGroundGrass());
    }

    public void LevelPreperations()
    {
        // Resetting Values
        lighting.color = new Color(1.0F, 0.957F, 0.839F, 1.0F);
        theTime = 0;
        gameOn = false;
        winText.text = "";
        
        winBronzeImage.gameObject.SetActive(false);
        winSilverImage.gameObject.SetActive(false);
        winGoldImage.gameObject.SetActive(false);

        restartButton.gameObject.SetActive(false);
        nextButton.gameObject.SetActive(false);
        previousButton.gameObject.SetActive(false);

        // Destroy All Objects except for Enemy
        DestroyAllObjects();

        // Setting up the Level
        if (gameLevel == 1)
        {
            GroundSize7x7();

            bronzeNumber = 10;
            silverNumber = 15;
            goldNumber = 20;

            boxCount = 12;
        }
        if (gameLevel == 2)
        {
            GroundSize9x9();

            bronzeNumber = 25;
            silverNumber = 33;
            goldNumber = 41;

            boxCount = 8;
        }
        if (gameLevel == 3)
        {
            GroundSize9x9();

            bronzeNumber = 41;
            silverNumber = 45;
            goldNumber = 49;

            boxCount = 20;
        }
        if (gameLevel == 4)
        {
            GroundSize9x9();

            bronzeNumber = 41;
            silverNumber = 45;
            goldNumber = 49;

            boxCount = 20;
        }
        if (gameLevel == 5)
        {
            GroundSize11x11();

            bronzeNumber = 41;
            silverNumber = 45;
            goldNumber = 49;

            boxCount = 20;
        }
        if (gameLevel == 6)
        {
            GroundSize5x5();

            bronzeNumber = 23;
            silverNumber = 26;
            goldNumber = 29;

            tarCount = 1;
            boxCount = 18;
        }


        // Updating Text
        levelText.text = "Level: " + gameLevel.ToString();
        boxText.text = "x " + boxCount.ToString();
        tarText.text = "x " + tarCount.ToString();
        stepsText.text = "0.0";

        bronzeText.text = bronzeNumber.ToString();
        silverText.text = silverNumber.ToString();
        goldText.text = goldNumber.ToString();

    }

    public IEnumerator BuildGroundGrass()
    {
        
        for (int x = GroundSize; x >= -GroundSize; x--)
        {
            for (int z = GroundSize; z >= -GroundSize; z--)
            {
                
                if (gameLevel == 1)
                {
                    InstantiateGroundGrass(x, z);
                }
                if (gameLevel == 2)
                {
                    if (!((Mathf.Abs(x) == 1 || Mathf.Abs(x) == 2 || Mathf.Abs(x) == 3) && (Mathf.Abs(z) == 1 || Mathf.Abs(z) == 3)))
                    {
                        InstantiateGroundGrass(x, z);
                    }             
                }
                if (gameLevel == 3)
                {
                    
                    if (!((Mathf.Abs(x) == 1 || Mathf.Abs(x) == 3) && (Mathf.Abs(z) == 1 || Mathf.Abs(z) == 3)))
                    {
                        InstantiateGroundGrass(x,z);                      
                    }
                 
                }
                if (gameLevel == 4)
                {
                    if (!((Mathf.Abs(x) == 0 || Mathf.Abs(x) == 2 || Mathf.Abs(x) == 3) && (Mathf.Abs(z) == 3)))
                    {
                        InstantiateGroundGrass(x, z);
                    }
                }
                if (gameLevel == 5)
                {
                    InstantiateGroundGrass(x, z);
                }
                if (gameLevel == 6)
                {
                    if ((x == 1.0 && z == 0))
                    {
                        // Warp up
                        Instantiate(Warp, new Vector3(x, 2.3F, z), Quaternion.identity);
                        Instantiate(LesserGround, new Vector3(x, 0.1F, z), Quaternion.identity);

                        // Ground + Grass down
                        Instantiate(Grass, new Vector3(x, -1.6F, z), Quaternion.identity);
                        Instantiate(LesserGround, new Vector3(x, -3.8F, z), Quaternion.identity);                      
                    }
                    else if ((x == 2.0 && z == 0.0))
                    {
                        // Ground + Grass up
                        Instantiate(Grass, new Vector3(x, 2.3F, z), Quaternion.identity);
                        Instantiate(LesserGround, new Vector3(x, 0.1F, z), Quaternion.identity);

                        // Warp down
                        Instantiate(Warp, new Vector3(x, -1.6F, z), Quaternion.identity);
                        Instantiate(LesserGround, new Vector3(x, -3.8F, z), Quaternion.identity);
                    }
                    else
                    {
                        NewInstantiateGroundGrass(x, z);
                    }
                    
                }

                yield return new WaitForSeconds(0.02F);
            }
        }

        // Stairs
        if (gameLevel == 6)
        {
            BuildStairsX(2, 3);
            BuildStairsZ(3, 2);
        }


        //surface.BuildNavMesh();
        StartCoroutine(WaitAndSurface());
        StartCoroutine(enemyController.WaitAndEnemy());
    }

    IEnumerator WaitAndSurface()
    {
        yield return new WaitForSeconds(1.5F);
        surface.BuildNavMesh();
    }

    void InstantiateGroundGrass(int x, int z)
    {
        Instantiate(Grass, new Vector3(x, 0.4F, z), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(x, -1.8F, z), Quaternion.identity);       
    }

    void NewInstantiateGroundGrass(int x, int z)
    {
        // Up
        Instantiate(Grass, new Vector3(x, 2.3F, z), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(x, 0.1F, z), Quaternion.identity);

        // Down
        Instantiate(Grass, new Vector3(x, -1.6F, z), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(x, -3.8F, z), Quaternion.identity);        
    }

    void BuildStairsX(int pX, int pZ)
    {
        // Start
        Instantiate(Grass, new Vector3(-pX, -1.6F, pZ), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(-pX, -3.8F, pZ), Quaternion.identity);
       

        Grass.transform.localScale -= new Vector3(0.5F, 0, 0.2F);
        LesserGround.transform.localScale -= new Vector3(0.5F, 0, 0.2F);

        float upY = 0;

        // Middle
        for (float x = -1.25F; x < 1.5; x+=0.5F)
        {
            upY += 0.5F;

            Instantiate(Grass, new Vector3(x, -1.6F+upY, 3.1F), Quaternion.identity);
            Instantiate(LesserGround, new Vector3(x, -3.8F+upY, 3.1F), Quaternion.identity);
        }

        Grass.transform.localScale = new Vector3(1, 0.2F, 1);
        LesserGround.transform.localScale = new Vector3(1, 1, 1);

        // End
        Instantiate(Grass, new Vector3(pX, 1.9F, pZ), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(pX, -0.3F, pZ), Quaternion.identity);

    }

    void BuildStairsZ(int pX, int pZ)
    {
        // Start
        Instantiate(Grass, new Vector3(pX, -1.6F, pZ), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(pX, -3.8F, pZ), Quaternion.identity);


        Grass.transform.localScale -= new Vector3(0.2F, 0, 0.5F);
        LesserGround.transform.localScale -= new Vector3(0.2F, 0, 0.5F);

        float upY = 0;

        // Middle
        for (float z = 1.25F; z > -1.5; z -= 0.5F)
        {
            upY += 0.5F;

            Instantiate(Grass, new Vector3(3.1F, -1.6F + upY, z), Quaternion.identity);
            Instantiate(LesserGround, new Vector3(3.1F, -3.8F + upY, z), Quaternion.identity);
        }

        Grass.transform.localScale = new Vector3(1, 0.2F, 1);
        LesserGround.transform.localScale = new Vector3(1, 1, 1);

        // End
        Instantiate(Grass, new Vector3(pX, 1.9F, -pZ), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(pX, -0.3F, -pZ), Quaternion.identity);

    }

    public void GameResult()
    {
        lighting.color = Color.black;

        stepSeconds = System.Math.Round(floatStepSeconds,1).ToString("f1");
        stepsText.text = stepSeconds;

        if (floatStepSeconds < bronzeNumber)
        {
            winText.text = "Try Again";
        }
        // Bronze
        if (floatStepSeconds >= bronzeNumber && floatStepSeconds < silverNumber)
        {
            winText.text = "BRONZE!";
            winBronzeImage.gameObject.SetActive(true);
            mainController.Medals[gameLevel - 1] = "Bronze";
        }
        // Silver
        if (floatStepSeconds >= silverNumber && floatStepSeconds < goldNumber)
        {
            winText.text = "SILVER!";
            winSilverImage.gameObject.SetActive(true);
            mainController.Medals[gameLevel - 1] = "Silver";
        }
        // Gold
        if (floatStepSeconds >= goldNumber)
        {
            winText.text = "GOLD!";
            winGoldImage.gameObject.SetActive(true);
            mainController.Medals[gameLevel - 1] = "Gold";
        }

        restartButton.gameObject.SetActive(true);

        if (gameLevel != 1) previousButton.gameObject.SetActive(true);
        if (floatStepSeconds >= bronzeNumber) nextButton.gameObject.SetActive(true);

    }

    void Update()
    {
        if (gameOn && !enemyController.gameOver)
        {
            theTime += Time.deltaTime * 1;
            stepSeconds = (theTime % 60).ToString("f1");
            floatStepSeconds = (theTime % 60);

            if ((System.Math.Round(floatStepSeconds, 1) * 10) % 2 == 0) stepsText.text = stepSeconds;
        }
    }

    public void BoxCount(int value)
    {
        boxCount += value;
        boxText.text = "x " + boxCount.ToString();
    }

    public void TarCount(int value)
    {
        tarCount += value;
        tarText.text = "x " + tarCount.ToString();
    }

    void GroundSize5x5()
    {
        GroundSize = 2;
        endPosition.transform.position = new Vector3(0, 1.7F, 0);
        startPosition.transform.position = new Vector3(-2.0F, -2.2F, -2.0F);
    }

    void GroundSize7x7()
    {
        GroundSize = 3;
        endPosition.transform.position = new Vector3(-4, -0.4F, 0);
        startPosition.transform.position = new Vector3(4, -0.4F, 0);

        Instantiate(LesserGround, new Vector3(-4, -1.8F, 0), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(4, -1.8F, 0), Quaternion.identity);
    }

    void GroundSize9x9()
    {
        GroundSize = 4;
        endPosition.transform.position = new Vector3(-5, -0.4F, 0);
        startPosition.transform.position = new Vector3(5, -0.4F, 0);
 
        Instantiate(LesserGround, new Vector3(-5, -1.8F, 0), Quaternion.identity);
        Instantiate(LesserGround, new Vector3(5, -1.8F, 0), Quaternion.identity);
    }

    void GroundSize11x11()
    {
        GroundSize = 5;
        endPosition.transform.position = new Vector3(-6, -0.8F, 0);
        startPosition.transform.position = new Vector3(6, -0.8F, 0);
    }

    void GroundSize13x13()
    {
        GroundSize = 6;
        endPosition.transform.position = new Vector3(-7, -0.8F, 0);
        startPosition.transform.position = new Vector3(7, -0.8F, 0);
    }

    void DestroyAllObjects()
    {
        destroyLesserGround = GameObject.FindGameObjectsWithTag("LesserGround");

        for (var i = 0; i < destroyLesserGround.Length; i++)
        {
            Destroy(destroyLesserGround[i]);
        }

        destroyGrass = GameObject.FindGameObjectsWithTag("Grass");

        for (var i = 0; i < destroyGrass.Length; i++)
        {
            Destroy(destroyGrass[i]);
        }

        destroyBox = GameObject.FindGameObjectsWithTag("Box");

        for (var i = 0; i < destroyBox.Length; i++)
        {
            Destroy(destroyBox[i]);
        }

        destroyWarp = GameObject.FindGameObjectsWithTag("Warp");

        for (var i = 0; i < destroyWarp.Length; i++)
        {
            Destroy(destroyWarp[i]);
        }

    }


}
