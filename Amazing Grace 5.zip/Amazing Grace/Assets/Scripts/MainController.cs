﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public class MainController : MonoBehaviour {

    public int CurrentLevel;

    public string[] Medals;

    void Awake()
    {
        DontDestroyOnLoad(this.gameObject);
    }
}
