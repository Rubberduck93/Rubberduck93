﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.AI;

public class EnemyController : MonoBehaviour {

    //public Camera cam;

    public NavMeshAgent agent;
    private NavMeshPath pathWarp0;
    private NavMeshPath pathWarp1;

    private Ray rayWarp0;
    private Ray rayWarp1;

    private RaycastHit hitWarp0;
    private RaycastHit hitWarp1;

    public Transform startPosition;
    public Transform endPosition;
   
    private GroundController groundController;

    private GameObject[] Warps;
    private GameObject Warp0;
    private GameObject Warp1;

    public bool gameOver = false;
    public bool falling = false;
    public bool warped = false;

    public void Start()
    {
        agent = GetComponent<NavMeshAgent>();

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();

        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        //gameObject.transform.position = startPosition.position;
        //print("Start: " + startPosition.position);
    }

    public void EnemyGo()
    {

        NavMeshPath pathEnd = new NavMeshPath();
        agent.CalculatePath(endPosition.position, pathEnd);

        //Ray ray = new Ray(endPosition.position += new Vector3(0, 1, 0), new Vector3(0,-1,0));
        //Ray ray = new Ray(new Vector3(-6, -0.4F, 0), new Vector3(0, -1, 0));

        // End Position
        Ray rayEnd = new Ray(new Vector3(endPosition.position.x, endPosition.position.y + 1, endPosition.position.z), new Vector3(0, -1, 0));
        RaycastHit hitEnd;

        Warps = GameObject.FindGameObjectsWithTag("Warp");

        if (Warps.Length > 0)
        {
            // Same Layer
            if ((agent.transform.position.y - Warps[0].transform.position.y) == (agent.transform.position.y - Warps[1].transform.position.y))
            {
                if (Vector3.Distance(agent.transform.position, Warps[0].transform.position) < Vector3.Distance(agent.transform.position, Warps[1].transform.position))
                {
                    Warp0 = Warps[0];
                    Warp1 = Warps[1];
                }
                else
                {
                    Warp1 = Warps[0];
                    Warp0 = Warps[1];
                }
            }
            else // 2 Layers
            {
                if ((agent.transform.position.y - Warps[0].transform.position.y) > (agent.transform.position.y - Warps[1].transform.position.y))
                {
                    Warp0 = Warps[0];
                    Warp1 = Warps[1];
                }
                else
                {
                    Warp1 = Warps[0];
                    Warp0 = Warps[1];
                }
            }

            // Closest Warp (Warp0)
            pathWarp0 = new NavMeshPath();
            agent.CalculatePath(Warp0.transform.position, pathWarp0);

            rayWarp0 = new Ray(new Vector3(Warp0.transform.position.x, Warp0.transform.position.y + 1, Warp0.transform.position.z), new Vector3(0, -1, 0));
            RaycastHit hitWarp0;

            // Furthest Warp (Warp1)
            pathWarp1 = new NavMeshPath();
            agent.CalculatePath(Warp1.transform.position, pathWarp1);

            rayWarp1 = new Ray(new Vector3(Warp1.transform.position.x, Warp1.transform.position.y + 1, Warp1.transform.position.z), new Vector3(0, -1, 0));
            RaycastHit hitWarp1;
        }     

        

        if (pathEnd.status == NavMeshPathStatus.PathComplete)
        {

            if (Physics.Raycast(rayEnd, out hitEnd))
            {
                // Move our agent
                agent.SetDestination(hitEnd.point);
            }

            groundController.gameOn = true;
        }
        else if (Warps.Length > 0)
        {
            if ((pathWarp0.status == NavMeshPathStatus.PathComplete) && !warped)
            {

                if (Physics.Raycast(rayWarp0, out hitWarp0))
                {
                    // Move our agent
                    agent.SetDestination(hitWarp0.point);
                }

                groundController.gameOn = true;
            }
            else if ((pathWarp1.status == NavMeshPathStatus.PathComplete) && !warped)
            {

                if (Physics.Raycast(rayWarp1, out hitWarp1))
                {
                    // Move our agent
                    agent.SetDestination(hitWarp1.point);
                }

                groundController.gameOn = true;
            }
        }     
        else
        {
            groundController.errorText.text = "There is no Path!";
            StartCoroutine(Wait());
        }
        
    }

    IEnumerator Wait()
    {
        yield return new WaitForSeconds(3.0F);
        groundController.errorText.text = "";      
    }

    void Update()
    {
        if (!gameOver && !falling && groundController.gameOn && !agent.pathPending)
            {
            if (agent.remainingDistance <= agent.stoppingDistance)
            {
                if (!agent.hasPath || agent.velocity.sqrMagnitude == 0f)
                {                  
                    groundController.GameResult();
                    gameOver = true;                  
                }
            }
        }
    }

        /*
            // Ice - for uncontrollable speed
            if (Input.GetKeyDown("space"))
            {
                print("speed up");
                agent.speed = 10;
            }
            */

    public IEnumerator WaitAndEnemy()
    {
        yield return new WaitForSeconds(2F);
        agent.Warp(startPosition.position);
        agent.ResetPath();
        gameOver = false;
        warped = false;
    }
}
