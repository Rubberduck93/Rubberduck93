﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ButtonController : MonoBehaviour {

    private GroundController groundController;
    private EnemyController enemyController;

    public GameObject MainCamera;

    // Use this for initialization
    void Start () {

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();

        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");
    }

    public void BuildAndGo()
    {
        if (!(groundController.gameOn))
        {
            groundController.surface.BuildNavMesh();
            enemyController.EnemyGo();
        }    
    }

    public void LevelChoice(int Level)
    {
        groundController.gameLevel += Level;
        groundController.ResetLevel();
    }

    public void BackToPanel()
    {
        SceneManager.LoadScene(1);
    }

    public void ChangeToggle(string choice)
    {
        GrassController.toggleChoice = choice;

        if (choice == "Box")
        {
            groundController.BoxToggle.anchoredPosition = new Vector2(130, -145);
            groundController.BoxBackground.sizeDelta = new Vector2(190, 60);

            groundController.TarToggle.anchoredPosition = new Vector2(95, -215);
            groundController.TarBackground.sizeDelta = new Vector2(120, 60);
        }

        if (choice == "Tar")
        {
            groundController.TarToggle.anchoredPosition = new Vector2(130, -215);
            groundController.TarBackground.sizeDelta = new Vector2(190, 60);

            groundController.BoxToggle.anchoredPosition = new Vector2(95, -145);
            groundController.BoxBackground.sizeDelta = new Vector2(120, 60);
        }
    }

    public void ChangeSlider(float value)
    {
        if (value <= 0.2F)
        {         
            MainCamera.transform.position = new Vector3(-14.5F, 6F, 0.4F);
            MainCamera.transform.rotation = Quaternion.Euler(24, 90, 0);         
        }
        if (value >= 0.2F && value <= 0.4F)
        {
            MainCamera.transform.position = new Vector3(-13, 5.5F, -5.5F);
            MainCamera.transform.rotation = Quaternion.Euler(24, 67.5F, 0);
        }
        if (value >= 0.4F && value <= 0.6F)
        {
            MainCamera.transform.position = new Vector3(-11, 6.5F, -11);
            MainCamera.transform.rotation = Quaternion.Euler(24, 45, 0);
        }
        if (value >= 0.6F && value <= 0.8F)
        {
            MainCamera.transform.position = new Vector3(-7, 7.5F, -17F);
            MainCamera.transform.rotation = Quaternion.Euler(24, 22.5F, 0);
        }
        if (value >= 0.8F)
        {
            MainCamera.transform.position = new Vector3(0, 7.5F, -18);
            MainCamera.transform.rotation = Quaternion.Euler(24, 0, 0);
        }

    }

}
