﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WarpController : MonoBehaviour {

    private GroundController groundController;
    private EnemyController enemyController;
    private WarpController otherWarpController;

    public Material Warp;
    public Material Warped;

    private Vector3 startPos;

    private GameObject otherWarp;

    bool findWarp = false;
    private bool steppedOn = false;
    public bool warping = false;

    // Use this for initialization
    void Start () {

        GameObject groundControllerObject = GameObject.FindWithTag("Ground");

        GameObject enemyControllerObject = GameObject.FindWithTag("Enemy");

        if (groundControllerObject != null) groundController = groundControllerObject.GetComponent<GroundController>();

        if (groundController == null) Debug.Log("Cannot find 'GroundController' script");

        if (enemyControllerObject != null) enemyController = enemyControllerObject.GetComponent<EnemyController>();

        if (enemyController == null) Debug.Log("Cannot find 'EnemyController' script");

        startPos = gameObject.transform.position;
    }

    void Update()
    {

        if (gameObject.transform.position.y > startPos.y - 0.8F)
        {
            gameObject.transform.position -= new Vector3(0, 0.01F, 0);
        }

        if (groundController.gameOn && !findWarp)
        {
            // Find the other warp
            GameObject[] otherWarpObject = GameObject.FindGameObjectsWithTag("Warp");
            foreach (GameObject warp in otherWarpObject)
            {
                if (!(warp.Equals(this.gameObject)))
                {
                    if (otherWarpObject != null) otherWarpController = warp.GetComponent<WarpController>();

                    if (otherWarpController == null) Debug.Log("Cannot find 'WarpController' script");

                    otherWarp = warp;
                }
            }
            findWarp = true;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (groundController.gameOn && !steppedOn)
        { 
            if (other.gameObject.tag == "Enemy")
            {
                //enemyController.agent.Warp(new Vector3(gameObject.transform.position.x, -1.9F, gameObject.transform.position.z));
                if (!warping)
                {
                    otherWarpController.warping = true;
                    enemyController.agent.Warp(otherWarp.transform.position);

                    GetComponent<Renderer>().material = Warped;
                    

                    enemyController.falling = true;
                    StartCoroutine(WaitForStep());
                }              
            }
        }
    }

    IEnumerator WaitForStep()
    {
        yield return new WaitForSeconds(0.1F);
        steppedOn = true;
        enemyController.warped = true;
        otherWarpController.GetComponent<Renderer>().material = Warped;

        groundController.surface.BuildNavMesh();
        enemyController.EnemyGo();
        StartCoroutine(WaitForFalling());
    }

    IEnumerator WaitForFalling()
    {
        yield return new WaitForSeconds(0.5F);
        enemyController.falling = false;
    }

}
